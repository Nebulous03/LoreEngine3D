#pragma once
#include "game\Scene.h"
#include "graphics\Camera.h"

class TestScene : public Scene {

private:

	double mouseDX = 0, mouseDY = 0;
	double lastMouseX = 0, lastMouseY = 0;
	bool capture = false;

public:

	TestScene();
	~TestScene();

	void onLoad();
	void onUnload();
	void onTick();
	void onUpdate();
	void onRender();

};