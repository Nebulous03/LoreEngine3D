#include "TestScene.h"
#include "utils\OBJLoader.h"
#include "logic\Input.h"
#include <iostream>
#include <GL\glew.h>

TestScene::TestScene() : Scene()
{
	_camera =  new Camera(vec3f(0, 0, 0), CAMERA_PERSPECTIVE, 640.0f, 480.0f);
	_renderer = new BasicRenderer(*_camera);
	_shader = new Shader("res/shaders/default.vs", "res/shaders/default.fs");
	_shader->bind();

	Mesh cubeMesh = loadMesh("res/meshs/cube.obj");
	Renderable cube(cubeMesh, *_shader, mat4f::Translation(0.0f, 0.0f, -3.0f));
	_renderables.push_back(cube);
}

TestScene::~TestScene()
{
	delete _shader;
	delete _renderer;
	delete _camera;
}

void TestScene::onLoad()
{
	
}

void TestScene::onUnload()
{

}

void TestScene::onTick()
{

}

void TestScene::onUpdate()
{

	mouseDX = Input::getMouseX() - lastMouseX;
	lastMouseX = Input::getMouseX();

	mouseDY = Input::getMouseY() - lastMouseY;
	lastMouseY = Input::getMouseY();

	if (capture && mouseDX != 0) { _camera->rotate(vec3f(0, 1, 0), 0.1f * (float)mouseDX); }
	if (capture && mouseDY != 0){ _camera->rotate(vec3f(1, 0, 0), 0.1f * (float)mouseDY); }

	mouseDX = mouseDY = 0;

	/*

	if (Input::isButtonPressed(GLFW_MOUSE_BUTTON_1))
	{
		//glfwSetInputMode(_game->getActiveWindow()->getGLWindow(), GLFW_CURSOR, GLFW_CURSOR_HIDDEN);
		capture = true;
	}

	if (Input::isKeyPressed(GLFW_KEY_ESCAPE))
	{
		glfwSetInputMode(_game->getActiveWindow()->getGLWindow(), GLFW_CURSOR, GLFW_CURSOR_NORMAL);
		capture = false;
	}

	if (capture)
	{
		glfwSetCursorPos(_game->getActiveWindow()->getGLWindow(), 640.0 / 2.0, 480.0 / 2.0);
	}

	*/

	if (Input::isKeyPressed(GLFW_KEY_UP)) { _camera->move(vec3f(0, 1, 0), 0.05f); }
	if (Input::isKeyPressed(GLFW_KEY_DOWN)) { _camera->move(vec3f(0, -1, 0), 0.05f); }
	if (Input::isKeyPressed(GLFW_KEY_LEFT)) { _camera->move(vec3f(-1, 0, 0), 0.05f); }
	if (Input::isKeyPressed(GLFW_KEY_RIGHT)) { _camera->move(vec3f(1, 0, 0), 0.05f); }

	if (Input::isKeyPressed(GLFW_KEY_G)) { _camera->move(vec3f(0, 0, -1), 0.05f); }
	if (Input::isKeyPressed(GLFW_KEY_H)) { _camera->move(vec3f(0, 0, 1), 0.05f); }

}

void TestScene::onRender()
{
	for (Renderable r : _renderables) _renderer->push(r);
	_renderer->flush();
}