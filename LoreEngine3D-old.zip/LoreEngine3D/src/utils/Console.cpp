#include "Console.h"

static void print()
{

}