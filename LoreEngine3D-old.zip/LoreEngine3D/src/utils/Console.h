#pragma once

static void print();
