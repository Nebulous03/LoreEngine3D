#include "Scene.h"

//Scene::Scene(BasicRenderer renderer, Shader& shader, Camera& camera) :
//	_renderer(renderer), _shader(shader), _camera(camera) {}

Scene::Scene() : _shader(nullptr), _renderer(nullptr), _camera(nullptr) {}

Shader& Scene::getShader()
{
	return *_shader;
}

Camera& Scene::getCamera()
{
	return *_camera;
}