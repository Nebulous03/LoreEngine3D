#pragma once
#include "../graphics/Renderable.h"
#include "../graphics/Renderer.h"
#include <vector>

class Scene {

protected:

	Shader* _shader;
	BasicRenderer* _renderer;
	Camera* _camera;

	std::vector<Renderable> _renderables;

	Scene();
	//Scene(BasicRenderer renderer, Shader& shader, Camera& camera);

public:

	virtual void onLoad()	= 0;
	virtual void onUnload() = 0;
	virtual void onTick()	= 0;
	virtual void onUpdate() = 0;
	virtual void onRender() = 0;

	Shader& getShader();
	Camera& getCamera();
};
