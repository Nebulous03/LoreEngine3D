#include "Mesh.h"
#include <iostream>

Index::Index(short vertex, short texCoord, short normal) :
	vi(vertex), ti(texCoord), ni(normal) {}

Index::Index() : vi(0), ti(0), ni(0) {}

Mesh::Mesh	// TODO: Allow texCoords w/o setting colors
(
	GLfloat* vertices, GLsizei vertexCount,
	GLushort* indices, GLsizei indicesCount,
	GLfloat* colors, GLsizei colorCount,
	GLfloat* texCoords, GLsizei texCoordCount
) 
{
	_vao = VertexArray();
	_vbo = Buffer(vertices, vertexCount, 3);
	_ibo = Buffer(indices, indicesCount);

	_vao.attach(&_vbo, 0);

	if (colors != nullptr)
	{
		_cbo = Buffer(colors, colorCount, 4);
		_vao.attach(&_cbo, 1);
		std::cout << "COLORS ENABLED" << std::endl;
	}

	if (texCoords != nullptr)
	{
		_tbo = Buffer(texCoords, texCoordCount, 3);
		_vao.attach(&_cbo, 2);
	}

}

VertexArray& Mesh::getVAO()
{
	return _vao;
}

Buffer& Mesh::getVBO()
{
	return _vbo;
}

Buffer& Mesh::getIBO()
{
	return _ibo;
}

Buffer& Mesh::getCBO()
{
	return _cbo;
}

Buffer& Mesh::getTBO()
{
	return _tbo;
}

Mesh Mesh::Plane
(
	GLfloat xSize, GLfloat ySize,
	GLfloat* colors, GLsizei colorCount,
	GLfloat* texCoords, GLsizei texCoordCount
)
{

	GLfloat vertices[] =
	{
		0,		0,		0,
		0,		ySize,  0,
		xSize,  ySize,  0,
		xSize,  0,		0,
	};

	GLushort indices[] =
	{
		0, 1, 2,
		2, 3, 0
	};

	return Mesh(vertices, 12, indices, 6, colors, colorCount, texCoords, texCoordCount);
}