LoreEngine2D V8.0 - C++

( Ill make this readme prettier later... )