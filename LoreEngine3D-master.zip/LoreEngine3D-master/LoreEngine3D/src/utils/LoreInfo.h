#pragma once

#define LORE_VERSION		"ALPHA 0.1.10a"
#define LORE_AUTHOR			"Ben Ratcliff (NebulousDev)"
#define LORE_COPYRIGHT		"(c) 2017 Ben Ratcliff - Apache 2.0"