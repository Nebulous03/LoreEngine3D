#pragma once
#include <Windows.h>

class Timer
{
private:
	LARGE_INTEGER _start;

public:
	Timer()
	{

	}
};